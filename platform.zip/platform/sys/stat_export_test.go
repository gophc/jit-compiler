package sys

const SysParseable = sysParseable
